//
// Created by viti on 11/18/2024.
//

#ifndef TUES_2024_5_MATHS_H
#define TUES_2024_5_MATHS_H
long factorial(long input);


#endif //TUES_2024_5_MATHS_H
