
#ifndef TUES_2024_5_TRANSFORMATION_H
#define TUES_2024_5_TRANSFORMATION_H
#include<string.h>
struct transformation{
    long result;
    char error[100];
};

struct transformation transform(char input[20]);

#endif //TUES_2024_5_TRANSFORMATION_H
